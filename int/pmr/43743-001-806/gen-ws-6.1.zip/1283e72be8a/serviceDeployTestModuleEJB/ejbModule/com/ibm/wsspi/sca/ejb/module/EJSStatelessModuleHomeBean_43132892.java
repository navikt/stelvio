package com.ibm.wsspi.sca.ejb.module;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessModuleHomeBean_43132892
 */
public class EJSStatelessModuleHomeBean_43132892 extends EJSHome {
	static final long serialVersionUID = 61;
	/**
	 * EJSStatelessModuleHomeBean_43132892
	 */
	public EJSStatelessModuleHomeBean_43132892() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create_Local
	 */
	public com.ibm.wsspi.sca.ejb.module.ServiceLocal create_Local() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.ibm.wsspi.sca.ejb.module.ServiceLocal result = null;
boolean createFailed = false;
boolean preCreateFlag = false;
try {
	result = (com.ibm.wsspi.sca.ejb.module.ServiceLocal) super.createWrapper_Local(null);
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
