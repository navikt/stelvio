import java.io.IOException;
import java.util.List;

import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceCallback;
import com.ibm.websphere.sca.ServiceImplAsync;
import com.ibm.websphere.sca.ServiceImplSync;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.ServiceRuntimeException;
import com.ibm.websphere.sca.Ticket;
import com.ibm.websphere.sca.scdl.Component;
import com.ibm.websphere.sca.scdl.OperationType;
import com.ibm.websphere.sca.scdl.Reference;

import commonj.sdo.DataObject;
import commonj.sdo.Type;

public class SerializeRequestImpl implements ServiceImplSync, ServiceImplAsync,
		ServiceCallback {
	private final Service partnerService;

	public SerializeRequestImpl() {
		ServiceManager serviceManager = ServiceManager.INSTANCE;

		Component component = serviceManager.getComponent();

		List references = component.getReferences();
		if (references.size() != 2) {
			throw new RuntimeException(
					"Component "
							+ component.getName()
							+ " should have 1 reference (in addition to self). Actual: "
							+ references.size());
		}
		for (Object ref : references) {
			Reference reference = (Reference) ref;
			if (!reference.getName().equals("self")) {
				partnerService = (Service) serviceManager
						.locateService(reference);
				return;
			}
		}

		throw new RuntimeException(
				"Unable to find partner service for component "
						+ component.getName() + ".");
	}

	public Object invoke(OperationType operationType, Object input)
			throws ServiceBusinessException {
		
		try {
			System.out.println("String representation: " + input);
			
			DataObject dataObject = (DataObject) input;
			
			Type type = dataObject.getType();
			System.out.print("BOXMLSerializer representation: ");
			getBOXMLSerializer().writeDataObject(dataObject, type.getURI(), type.getName(), System.out);
			
			return partnerService.invoke(operationType, input);
		} catch (IOException e) {
			throw new ServiceRuntimeException(e);
		}
	}

	public void invokeAsync(OperationType operationType, Object input,
			ServiceCallback callback, Ticket ticket) {
		throw new UnsupportedOperationException(
				"Async invokation is currently unsupported");
	}

	public void onInvokeResponse(Ticket ticket, Object output,
			Exception exception) {
		throw new UnsupportedOperationException(
				"Async invokation is currently unsupported");
	}
	
	private BOXMLSerializer getBOXMLSerializer() {
		return (BOXMLSerializer) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOXMLSerializer");
	}
}