package ejbs;

import java.rmi.RemoteException;

/**
 * Remote interface for Enterprise Bean: EchoBean
 */
public interface EchoBean extends javax.ejb.EJBObject {
	StringHolder echo(StringHolder input) throws RemoteException;
}
