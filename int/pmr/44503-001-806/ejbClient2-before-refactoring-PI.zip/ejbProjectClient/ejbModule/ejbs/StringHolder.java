package ejbs;

import java.io.Serializable;

public class StringHolder implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1858680056852858903L;

	private String string;

	public String getString() {
		return string;
	}

	public void setString(String string) {
		this.string = string;
	}
}
