package ejbs;

/**
 * Home interface for Enterprise Bean: EchoBean
 */
public interface EchoBeanHome extends javax.ejb.EJBHome {

	/**
	 * Creates a default instance of Session Bean: EchoBean
	 */
	public ejbs.EchoBean create()
		throws javax.ejb.CreateException,
		java.rmi.RemoteException;
}
